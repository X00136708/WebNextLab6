webpackHotUpdate("static\\development\\pages\\about.js",{

/***/ 3:
false,

/***/ 6:
/*!******************************!*\
  !*** multi ./pages/about.js ***!
  \******************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! ./pages/about.js */"./pages/about.js");


/***/ })

})
//# sourceMappingURL=about.js.a074ae69367c9e2e708f.hot-update.js.map