// Import App and Container dependencies
import App, { Container } from 'next/app';
import page from '../components/page';
// Define the custom App - a class which extents the default App
class MyApp extends App {
 render() {
 // Compent will be the page content
 // e.g. index or about
 const {Component} = this.props;
 return (
 // Container contains page content
 <Container>
 <page>
 {/* Content which will be shared */}
 <p>On every page</p>
 {/* Compontent is page e.g. index or about */}
 <Component />
 </page>
 </Container>
 );
 }
}
export default MyApp;
