import Link from 'next/link';
import fetch from 'isomorphic-unfetch';
import './components/style.css';

const source = 'hacker-news';

const apiKey ='3780066b33ef41b9b4b7e957994e9c38';

const url = `https://newsapi.org/v2/top-headlines?sources=${source}&apiKey=${apiKey}`;



const News = props => (
	<div>
		<h2>News from {source.split("-").join(" ")}</h2>
	<div>
	
	<div class="dropdown">
  <button class="dropbtn">Dropdown</button>
  <div class="dropdown-content">
    <a href="#">Link 1</a>
    <a href="#">Link 2</a>
    <a href="#">Link 3</a>
  </div>
</div>

	{props.articles.map(article => (
	<section>
	<h3>{article.title}</h3>
	<p className = "author"> {article.author} {article.publishedAt}</p>
	<img src = {article.urlToImage} alt="article image" className="img-article"></img>
	<p>{article.description}</p>
	<p>{article.content}</p>
	<p><Link href="/story"> Read more</Link></p>
	</section>
	))}
	</div>
	</div>
		);


News.getInitialProps = async function(){
	const res = await fetch(url);
	const data = await res.json();
	console.log(`Show data fetched. Count: ${data.articles.length}`);
	return {
		articles: data.articles
	}
}

export default News;




	
	
	
